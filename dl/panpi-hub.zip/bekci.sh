#!/data/data/com.termux/files/usr/bin/bash
# ═══════════════════════════════════════════════════════════
# PanpiKontrol servis BEKÇİSİ (A5)
# hub / phone / a5-remote'den biri çökerse 15 sn içinde yeniden başlatır.
# start-all.sh tarafından başlatılır; Termux:Boot boot scriptinde de var.
# Not: Bu, Termux'un kendisinin öldürülmesine karşı koruyamaz — o koruma
# pil istisnası + wake-lock ile (Ayarlar > Termux > Pil > Kısıtlama yok).
# ═══════════════════════════════════════════════════════════
cd ~/panpi-hub || exit 1

ensure() {
  local name="$1" log="$2"
  if ! pgrep -f "node $name" >/dev/null 2>&1; then
    echo "$(date '+%H:%M:%S') [bekci] $name ölmüştü — yeniden başlatıldı" >> bekci.log
    nohup node "$name" >> "$log" 2>&1 &
    sleep 3
  fi
}

echo "$(date '+%H:%M:%S') [bekci] başladı (15 sn'de bir kontrol)"
while true; do
  ensure hub.js hub.log
  ensure phone-svc.js phone.log
  ensure a5-remote.js a5-remote.log
  sleep 15
done