#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# A5 arayüz + performans optimizasyonu (ROOT GEREKMEZ, GERİ ALINABİLİR)
# - Animasyonlar kapatılır → telefon akıcılaşır
# - Ekran 30 dk açık kalır (sunucu modu) + şarjdayken uyanık
# - Sadece ÇÖP Samsung paketleri devre dışı bırakılır (pm enable ile geri açılır)
# - Sıfır risk: sistem paketlerine dokunulmaz, veri silinmez
# Kullanım: bash optimize-a5.sh
# ═══════════════════════════════════════════════════════════════
set -u
ADB="${ADB:-/c/Users/emin-/AppData/Local/Android/Sdk/platform-tools/adb.exe}"

echo "═══ A5 optimizasyon ═══"
"$ADB" devices | tail -2

echo "[1/4] animasyonlar kapatılıyor (UI akıcılığı)…"
"$ADB" shell settings put global window_animation_scale 0
"$ADB" shell settings put global transition_animation_scale 0
"$ADB" shell settings put global animator_duration_scale 0
echo "  ✓ animasyonlar kapalı"

echo "[2/4] sunucu modu (ekran 30 dk + şarjda uyanık)…"
"$ADB" shell settings put system screen_off_timeout 1800000
"$ADB" shell settings put global stay_on_while_plugged_in 7
echo "  ✓ ekran 30 dk / şarjda hep açık"

echo "[3/4] WiFi uyku politikası (bağlıyken asla uyuma)…"
"$ADB" shell settings put global wifi_sleep_policy 2
echo "  ✓ WiFi hep açık"

echo "[4/4] çöp Samsung paketleri (var olanlar kapatılır — geri alınabilir)…"
# Sadece GÜVENLİ listedekiler: kullanıcının işine yarayabilecek hiçbir şey yok
# (Ana ekran, arama, mesajlar, kamera, galeri, ayarlar vb. DOKUNULMAZ)
JUNK=(
  com.samsung.android.svoice            # S Voice (eski asistan)
  com.samsung.android.game.gamehome     # Oyun Merkezi
  com.samsung.android.game.gametools     # Oyun Araçları
  com.samsung.android.app.spage          # Briefing ana ekran
  com.samsung.android.storyalbum         # Hikaye Albümü
  com.samsung.android.bixby.wakeup       # Bixby (varsa)
  com.samsung.android.app.settings.bixby # Bixby Ayarları (varsa)
)
for pkg in "${JUNK[@]}"; do
  if "$ADB" shell pm list packages 2>/dev/null | grep -q "package:$pkg"; then
    "$ADB" shell pm disable-user --user 0 "$pkg" >/dev/null 2>&1 && echo "  ✓ $pkg kapalı (geri aç: pm enable $pkg)"
  fi
done

echo "[+] GC/arka plan…"
"$ADB" shell settings put global background_limit 8 2>/dev/null
"$ADB" shell settings put secure immersive_mode_confirmations confirmed 2>/dev/null

echo ""
echo "═══ BİTTİ — telefon artık sunucu modunda ═══"
echo "Geri almak istersen: ayarların hepsi 'settings put ... 1' yapılır, paketler 'pm enable' ile açılır."