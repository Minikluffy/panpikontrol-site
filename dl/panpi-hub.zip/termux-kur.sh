#!/data/data/com.termux/files/usr/bin/bash
# ═══════════════════════════════════════════════════════════
# panpi-hub — Termux tek komut kurulum
# Kullanım (Termux'ta):
#   bash termux-kur.sh
# Ne yapar:
#   1) nodejs + termux-services kurar
#   2) panpi-hub dosyalarını ~/panpi-hub'a kopyalar (script yanındaysa)
#      veya mevcut dosyaları kullanır
#   3) termux-wake-lock + pil optimizasyonu hatırlatması
#   4) Termux:Boot için otomatik başlatma scripti yazar
# ═══════════════════════════════════════════════════════════
set -e
echo "═══ panpi-hub kurulumu başlıyor ═══"

echo "[1/5] paketler…"
pkg update -y -q 2>/dev/null || pkg update -y
pkg install -y nodejs-lts termux-services -q 2>/dev/null || pkg install -y nodejs-lts termux-services

echo "[2/5] dosyalar…"
mkdir -p ~/panpi-hub
SRC="$(cd "$(dirname "$0")" && pwd)"
cp -f "$SRC/hub.js" ~/panpi-hub/hub.js 2>/dev/null || { echo "  hub.js yanında değil — zaten kurulu mu bakılıyor"; [ -f ~/panpi-hub/hub.js ] || { echo "HATA: hub.js bulunamadı"; exit 1; }; }

echo "[3/5] wake-lock…"
command -v termux-wake-lock >/dev/null && termux-wake-lock || echo "  termux-api yok — pil optimizasyonunu elle kapat: Ayarlar > Uygulamalar > Termux > Pil > Kısıtlama yok"

echo "[4/5] otomatik başlatma (Termux:Boot)…"
mkdir -p ~/.termux/boot
cat > ~/.termux/boot/panpi-hub.sh <<EOF
#!/data/data/com.termux/files/usr/bin/bash
termux-wake-lock
sleep 10
cd ~/panpi-hub
exec node hub.js >> hub.log 2>&1
EOF
chmod +x ~/.termux/boot/panpi-hub.sh
echo "  boot scripti yazıldı (Termux:Boot eklentisi kuruluysa açılışta otomatik çalışır)"

echo "[5/5] ilk başlatma…"
pkill -f 'node hub.js' 2>/dev/null || true
sleep 1
cd ~/panpi-hub
nohup node hub.js >> hub.log 2>&1 &
sleep 3
if curl -s -m 3 http://127.0.0.1:8443/health | grep -q '"ok":true'; then
  TOKEN=$(cat data/hub-token)
  echo ""
  echo "═══ HUB ÇALIŞIYOR ✓ ═══"
  echo "  panel : http://$(ifconfig 2>/dev/null | grep -oE 'inet (192|10|172)[^ ]*' | head -1 | cut -d' ' -f2):8443"
  echo "  token : $TOKEN"
  echo "  (bu token'ı E·MERKEZ'deki A5 uygulamasına ve PC ajanına gireceksin)"
else
  echo "hata: hub başlamadı — log:"
  tail -20 hub.log
  exit 1
fi
