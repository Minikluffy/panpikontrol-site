#!/data/data/com.termux/files/usr/bin/bash
# ═══════════════════════════════════════════════════════════
# panpi-hub servislerini başlat + durum göster (tek satır)
# Kullanım (Termux'ta):  bash start-all.sh
# Tüm servisleri yeniden başlatır, sağlık kontrolü yapar,
# token'ı ekrana basar (E·MERKEZ'e girmek için).
# ═══════════════════════════════════════════════════════════
cd ~/panpi-hub || { echo "HATA: ~/panpi-hub yok — önce: bash termux-kur.sh"; exit 1; }

echo "═══ PanpiKontrol servisleri başlatılıyor ═══"
command -v termux-wake-lock >/dev/null && termux-wake-lock

pkill -f 'node hub.js' 2>/dev/null
pkill -f 'node phone-svc.js' 2>/dev/null
pkill -f 'node a5-remote.js' 2>/dev/null
sleep 1

nohup node hub.js >> hub.log 2>&1 &
sleep 2
nohup node phone-svc.js >> phone.log 2>&1 &
nohup node a5-remote.js >> a5-remote.log 2>&1 &
sleep 3

HUB_OK=no;   curl -s -m 3 http://127.0.0.1:8443/health | grep -q '"ok":true' && HUB_OK=yes
PHONE_OK=no; curl -s -m 3 http://127.0.0.1:8555/health | grep -q '"ok":true' && PHONE_OK=yes
REMOTE_OK=no; curl -s -m 3 http://127.0.0.1:8556/health | grep -q '"ok":true' && REMOTE_OK=yes

TOKEN=$(cat data/hub-token 2>/dev/null)
LANIP=$(ifconfig 2>/dev/null | grep -oE 'inet (192|10|172)[^ ]*' | head -1 | cut -d' ' -f2)

echo ""
echo "═══ HUB    : $HUB_OK  (http://$LANIP:8443) ═══"
echo "═══ PHONE  : $PHONE_OK (http://$LANIP:8555) ═══"
echo "═══ REMOTE : $REMOTE_OK (http://$LANIP:8556 — ekran, root gerekir) ═══"
[ -n "$TOKEN" ] && echo "  token : $TOKEN" || echo "  token : YOK — ilk açılışta hub.js üretir, biraz bekle"
echo ""
echo "Not: Termux arka planda ölmesin → Ayarlar > Uygulamalar > Termux > Pil > Kısıtlama yok"
echo "     ve Termux'u son uygulamalardan kaydırma. (Boot kuruluysa telefon açılınca da otomatik başlar)"