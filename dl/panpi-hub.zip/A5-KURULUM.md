# A5 kurulumu — iki yol

## YOL A: USB varsa (otomatik)
USB'yi tak, ben hallediyorum:
  bash a5-sunucu/kur-telefonda.sh

## YOL B: USB yoksa (telefonda Termux'a tek satır)
Termux'u aç (ilk açılışta bootstrap bitmesini bekle ~2 dk), sonra şunu yaz:

pkg install -y unzip && curl -sL -o ~/hub.zip https://minikluffy.github.io/panpikontrol-site/dl/panpi-hub.zip && unzip -o ~/hub.zip -d ~/hub-src && bash ~/hub-src/termux-kur.sh

Script 5-10 dk sürer (node indirir). Bitince ekranda şunları verir:
  panel : http://<telefon-ip>:8443
  token : <hub-token>

O token'ı bana söyle → PC ajanına ben bağlarım.

## Kurulumdan sonra pil ayarı (elle, tek sefer)
Ayarlar > Uygulamalar > Termux > Pil > Kısıtlama yok (Kısıtlanmamış)
(Bu olmadan Android 7 ekran kapayınca node'u öldürür.)
