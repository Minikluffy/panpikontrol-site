# A5 Sunucu Kurulumu (ROOT'SUZ — işletim sistemi SİLİNMEZ)

> ⚠️ Karar: **A5'in Android'i aynen kalır.** Root/flash/OEM unlock YOK (veri siler).
> Mikrofon, kamera, hoparlör, flaş, titreşim — hepsi **Termux:API** ile root'suz çalışır.

## Ne kuruluyor (3 servis)
| Servis | Port | Görevi |
|---|---|---|
| **panpi-hub** | 8443 | PC'lerin kaydı, keşif, güvenlik olayları, WOL, panel |
| **panpi-phone** | 8555 | Mikrofon kaydı, kamera foto, TTS/medya (hoparlör), ses seviyesi, flaş, titreşim, pil durumu |
| **a5-remote** | 8556 | **A5 ekranını canlı izle + dokunmatik/tuş kontrol** (root gerekir — SuperSU kuruluysa tam çalışır; değilse 501 döner, diğer servisler etkilenmez) |

> 📱 **Ekran kontrolü:** A5'i E·MERKEZ → 📟 A5 Hub → "A5 Ekranı" panelinden izleyip kontrol edersin (dokun = tık, sürükle = kaydırma, tuşlar: home/geri/son uygulamalar/güç/ses).

## YOL A — USB ile (otomatik, önerilen)
1. Telefonu USB'ye tak (USB hata ayıklama açık)
2. PC'de: `bash a5-sunucu/kur-telefonda.sh`
   - Termux:API uygulamasını kurar, dosyaları iter, izinleri verir (mik/kamera),
     hub + phone'u başlatır, **kablosuz ADB** açar
3. Telefon ekranında Termux kurulum sihirbazı çıkarsa **İZİN VER**'e dokun (APK)
4. Bitti → optimize için: `bash a5-sunucu/optimize-a5.sh` (animasyon kapatma, çöp paketler — geri alınabilir)

## YOL B — Sitesiz, tek satır (Termux'ta yapıştır)
Termux'u aç (F-Droid sürümü), şunu yapıştır:
```
pkg install -y unzip && curl -sL -o ~/hub.zip https://minikluffy.github.io/panpikontrol-site/dl/panpi-hub.zip && unzip -o ~/hub.zip -d ~/hub-src && bash ~/hub-src/termux-kur.sh
```
Kurulum sonunda ekrana **token** düşer + Termux:API APK kurulumu açılır (İZİN VER).

## Sonra
1. **Token'ı kaydet** — E·MERKEZ'deki 📟 A5 Hub uygulamasına ve PC ajanına gireceksin
2. **Termux:API kurulumu** tamamlandıysa telefon servisi (8555) çalışır:
   `curl http://<A5-IP>:8555/health`
3. PC ajanı hub'a kaydolur, telefon hub'dan PC'yi bulur — zincir tamam

## Servisleri başlat / yeniden başlat (her seferinde tek satır)
```
bash ~/panpi-hub/start-all.sh
```
→ 3 servisi + **bekçiyi** başlatır; bekçi (bekci.sh) bir servis çökerse 15 sn içinde yeniden ayağa kaldırır. Token'ı da ekrana basar.

## Servis kontrolü
```
curl -s http://<A5-IP>:8443/health   # hub
curl -s http://<A5-IP>:8555/health   # phone (mik/kamera/hoparlör)
curl -s http://<A5-IP>:8556/health   # a5-remote (ekran izle + kontrol, root gerekir)
```
