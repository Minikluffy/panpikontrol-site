'use strict';
/*
 * ═══════════════════════════════════════════════════════════════════
 * panpi-phone — Telefon donanım servisi (mikrofon/kamera/hoparlör)
 * Samsung A5 (Termux içinde) üzerinde çalışır, root GEREKMEZ.
 *
 * • Termux:API uygulaması + termux-api paketi şart (kurulum scripti halleder)
 * • Port: 8555 (LAN içi) — token korumalı, kilitli, hız sınırlı
 * • Tüm komutlar termux-api aracılığıyla: mic kayıt, kamera foto,
 *   TTS (hoparlör), medya oynatma, ses seviyesi, flaş, titreşim, pil
 * • Hub'a kendini kaydeder → PC/telefon "telefon nerede?" diye bulur
 * ═══════════════════════════════════════════════════════════════════
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');

const HOME = process.env.HOME || process.env.TERMUX_HOME || '/data/data/com.termux/files/home';
const DATA_DIR = path.join(HOME, 'panpi-hub', 'data');
const MEDIA_DIR = path.join(DATA_DIR, 'media');
const TOKEN_FILE = path.join(DATA_DIR, 'phone-token');
const HUB_TOKEN_FILE = path.join(DATA_DIR, 'hub-token');
const REG_FILE = path.join(DATA_DIR, 'phone-reg.json');
const PORT = 8555;

for (const d of [DATA_DIR, MEDIA_DIR]) fs.mkdirSync(d, { recursive: true });

const started = Date.now();
let token = '';
try { token = fs.readFileSync(TOKEN_FILE, 'utf8').trim(); } catch (_) {}
if (!token) {
  token = crypto.randomBytes(9).toString('base64').replace(/[^a-zA-Z0-9]/g, '').slice(0, 12);
  fs.writeFileSync(TOKEN_FILE, token, { mode: 0o600 });
}

/* kilit + hız sınırı (hub ile aynı damar) */
const failMap = new Map();
const hitMap = new Map();
function locked(ip) {
  const e = failMap.get(ip);
  return e && e.until > Date.now();
}
function authed(req, ip) {
  const a = req.headers.authorization || '';
  return a === 'Bearer ' + token;
}
function noteFail(ip) {
  const e = failMap.get(ip) || { n: 0, until: 0 };
  e.n++;
  if (e.n >= 5) { e.until = Date.now() + 15 * 60 * 1000; e.n = 0; }
  failMap.set(ip, e);
}
function limited(ip) {
  const h = hitMap.get(ip) || { n: 0, t: Date.now() };
  if (Date.now() - h.t > 60000) { h.n = 0; h.t = Date.now(); }
  h.n++;
  hitMap.set(ip, h);
  return h.n > 120;
}
function lanIP() {
  try {
    const out = require('child_process').execSync('ifconfig 2>/dev/null || ip -4 addr 2>/dev/null', { timeout: 2000 }).toString();
    const m = out.match(/inet (?:addr:)?(192\.168\.|10\.|172\.(?:1[6-9]|2\d|3[01])\.)[0-9.]+/g) || [];
    const ip = m.map(s => s.replace(/inet\s*|addr:/g, '')).find(i => i !== '127.0.0.1');
    if (ip) return ip;
  } catch (_) {}
  return '';
}

function send(res, code, obj) {
  const b = JSON.stringify(obj);
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'authorization, content-type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Cache-Control': 'no-store',
  });
  res.end(b);
}
/* termux-api komut çalıştır (sessiz, timeout'lu) */
function run(cmd, args, timeout = 15000) {
  return new Promise(res => {
    execFile(cmd, args, { timeout, maxBuffer: 8 * 1024 * 1024 }, (err, stdout, stderr) => {
      if (err) return res({ ok: false, err: String(err.message || err).slice(0, 200), out: String(stdout).slice(0, 400), errOut: String(stderr).slice(0, 400) });
      res({ ok: true, out: String(stdout).slice(0, 4000), errOut: String(stderr).slice(0, 400) });
    });
  });
}
function runBg(cmd, args) {
  try {
    const p = execFile(cmd, args, { detached: true, stdio: 'ignore' });
    p.unref();
    return { ok: true };
  } catch (e) { return { ok: false, err: String(e).slice(0, 200) }; }
}

let recording = false;
function serveFile(res, name) {
  const p = path.join(MEDIA_DIR, path.basename(name));
  if (!fs.existsSync(p)) return send(res, 404, { error: 'yok' });
  const ct = /\.(jpe?g|png)$/i.test(p) ? 'image/jpeg' : /\.(m4a|aac|mp3)$/i.test(p) ? 'audio/mp4' : 'application/octet-stream';
  res.writeHead(200, { 'Content-Type': ct, 'Content-Length': fs.statSync(p).size, 'Access-Control-Allow-Origin': '*', 'Cache-Control': 'no-store' });
  fs.createReadStream(p).pipe(res);
}

const server = http.createServer(async (req, res) => {
  const ip = (req.socket.remoteAddress || '').replace(/^::ffff:/, '');
  if (req.method === 'OPTIONS') { res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, content-type', 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS' }); return res.end(); }
  const u = new URL(req.url, 'http://x');
  const p = u.pathname;

  if (p === '/health') return send(res, 200, { ok: true, name: 'panpi-phone', v: 1, up: Math.round((Date.now() - started) / 1000), recording });

  /* token isteyenler — kilitli IP her şeyi reddedilir (doğru token bile) */
  if (locked(ip)) return send(res, 423, { error: 'kilitli' });
  if (!authed(req, ip)) {
    noteFail(ip);
    return send(res, 401, { error: 'yetkisiz' });
  }
  if (limited(ip)) return send(res, 429, { error: 'hız sınırı' });

  /* ── MİKROFON ─────────────────────────────────────────── */
  if (p === '/mic/start' && req.method === 'POST') {
    if (recording) return send(res, 409, { error: 'zaten kayıtta' });
    recording = true;
    runBg('termux-microphone-record', ['-f', path.join(MEDIA_DIR, 'mic-live.m4a')]);
    return send(res, 200, { ok: true, msg: 'kayıt başladı' });
  }
  if (p === '/mic/stop' && req.method === 'POST') {
    recording = false;
    await run('termux-microphone-record', ['-q']);
    const f = path.join(MEDIA_DIR, 'mic-live.m4a');
    return send(res, 200, { ok: true, file: fs.existsSync(f) ? 'mic-live.m4a' : null });
  }
  if (p === '/mic/snap' && req.method === 'POST') {
    // kısa kayıt: secs saniye sonra otomatik durur
    let body = '';
    req.on('data', c => { body += c; if (body.length > 1024) req.destroy(); });
    req.on('end', async () => {
      try {
        const j = JSON.parse(body || '{}');
        const secs = Math.min(Math.max(parseInt(j.secs || '5', 10), 1), 60);
        const name = 'mic-' + Date.now() + '.m4a';
        const full = path.join(MEDIA_DIR, name);
        const r = await run('termux-microphone-record', ['-f', full, '-l', String(secs)], (secs + 8) * 1000);
        if (!r.ok) return send(res, 500, { error: 'mic hatası', err: r.err, out: r.out });
        return send(res, 200, { ok: true, file: name });
      } catch (e) { send(res, 400, { error: 'json hatalı' }); }
    });
    return;
  }

  /* ── KAMERA ───────────────────────────────────────────── */
  if (p === '/cam' && req.method === 'POST') {
    let body = '';
    req.on('data', c => { body += c; if (body.length > 1024) req.destroy(); });
    req.on('end', async () => {
      try {
        const j = JSON.parse(body || '{}');
        const which = String(j.cam || 'back').toLowerCase().startsWith('front') ? 1 : 0;
        const name = 'photo-' + Date.now() + '.jpg';
        const full = path.join(MEDIA_DIR, name);
        const r = await run('termux-camera-photo', ['-c', String(which), full], 20000);
        if (!r.ok || !fs.existsSync(full)) return send(res, 500, { error: 'kamera hatası', err: r.err, out: r.out });
        return send(res, 200, { ok: true, file: name });
      } catch (e) { send(res, 400, { error: 'json hatalı' }); }
    });
    return;
  }

  /* ── HOPARLÖR / SES ───────────────────────────────────── */
  if (p === '/tts' && req.method === 'POST') {
    let body = '';
    req.on('data', c => { body += c; if (body.length > 4096) req.destroy(); });
    req.on('end', async () => {
      try {
        const j = JSON.parse(body || '{}');
        const text = String(j.text || '').slice(0, 500);
        if (!text) return send(res, 400, { error: 'text gerekli' });
        const r = await run('termux-tts-speak', [text]);
        return r.ok ? send(res, 200, { ok: true }) : send(res, 500, { error: 'tts hatası', err: r.err });
      } catch (e) { send(res, 400, { error: 'json hatalı' }); }
    });
    return;
  }
  if (p === '/play' && req.method === 'POST') {
    // telefonda mutlak dosya yolu (örn: /sdcard/Music/sarki.mp3)
    let body = '';
    req.on('data', c => { body += c; if (body.length > 2048) req.destroy(); });
    req.on('end', async () => {
      try {
        const j = JSON.parse(body || '{}');
        const file = String(j.path || '').slice(0, 500);
        if (!file.startsWith('/')) return send(res, 400, { error: 'mutlak yol gerekli' });
        const r = await run('termux-media-player', ['play', file], 8000);
        return r.ok ? send(res, 200, { ok: true }) : send(res, 500, { error: 'oynatma hatası', err: r.err, out: r.out });
      } catch (e) { send(res, 400, { error: 'json hatalı' }); }
    });
    return;
  }
  if (p === '/vol' && req.method === 'GET') {
    const r = await run('termux-volume', ['music']);
    let level = -1;
    const m = r.out.match(/volume:\s*(\d+)/);
    if (m) level = parseInt(m[1], 10);
    return send(res, 200, { ok: true, level, raw: r.out.trim() });
  }
  if (p === '/vol' && req.method === 'POST') {
    let body = '';
    req.on('data', c => { body += c; if (body.length > 256) req.destroy(); });
    req.on('end', async () => {
      try {
        const j = JSON.parse(body || '{}');
        const lvl = parseInt(j.level, 10);
        if (isNaN(lvl) || lvl < 0 || lvl > 15) return send(res, 400, { error: 'level 0-15' });
        const r = await run('termux-volume', ['music', String(lvl)]);
        return r.ok ? send(res, 200, { ok: true, level: lvl }) : send(res, 500, { error: r.err });
      } catch (e) { send(res, 400, { error: 'json hatalı' }); }
    });
    return;
  }

  /* ── FLAŞ / TİTREŞİM ──────────────────────────────────── */
  if (p === '/flash' && req.method === 'POST') {
    let body = '';
    req.on('data', c => { body += c; if (body.length > 256) req.destroy(); });
    req.on('end', async () => {
      try {
        const j = JSON.parse(body || '{}');
        const on = !!j.on;
        const r = await run('termux-torch', [on ? 'on' : 'off'], 5000);
        return r.ok ? send(res, 200, { ok: true, on }) : send(res, 500, { error: r.err });
      } catch (e) { send(res, 400, { error: 'json hatalı' }); }
    });
    return;
  }
  if (p === '/vibrate' && req.method === 'POST') {
    let body = '';
    req.on('data', c => { body += c; if (body.length > 256) req.destroy(); });
    req.on('end', async () => {
      try {
        const j = JSON.parse(body || '{}');
        const ms = Math.min(Math.max(parseInt(j.ms || '300', 10), 0), 10000);
        const r = await run('termux-vibrate', ['-d', String(ms)], 12000);
        return r.ok ? send(res, 200, { ok: true, ms }) : send(res, 500, { error: r.err });
      } catch (e) { send(res, 400, { error: 'json hatalı' }); }
    });
    return;
  }

  /* ── DURUM ────────────────────────────────────────────── */
  if (p === '/status' && req.method === 'GET') {
    const bat = await run('termux-battery-status');
    let b = {};
    try { b = JSON.parse(bat.out); } catch (_) {}
    const wifi = await run('termux-wifi-connectioninfo');
    let w = {};
    try { w = JSON.parse(wifi.out); } catch (_) {}
    return send(res, 200, {
      ok: true,
      battery: { level: b.percentage ?? -1, charging: b.status === 'CHARGING', plugged: b.plugged },
      wifi: { ssid: w.ssid || '', ip: w.ip || lanIP(), rssi: w.rssi ?? null },
      recording,
    });
  }

  /* ── DOSYALAR (foto/kayıt paylaşımı) ───────────────────── */
  if (p === '/files' && req.method === 'GET') {
    const list = fs.readdirSync(MEDIA_DIR).filter(f => !f.startsWith('.')).sort().reverse().slice(0, 50);
    return send(res, 200, { ok: true, files: list });
  }
  if (p.startsWith('/file/') && req.method === 'GET') {
    return serveFile(res, decodeURIComponent(p.slice(6)));
  }

  /* ── HUB KAYDI ─────────────────────────────────────────── */
  if (p === '/register' && req.method === 'POST') {
    let hubUrl = '';
    try { hubUrl = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'phone-reg.json'), 'utf8')).hub || ''; } catch (_) {}
    let body = '';
    req.on('data', c => { body += c; if (body.length > 2048) req.destroy(); });
    req.on('end', () => {
      try {
        const j = JSON.parse(body || '{}');
        if (j.hub) {
          hubUrl = String(j.hub).replace(/\/+$/, '');
          fs.writeFileSync(REG_FILE, JSON.stringify({ hub: hubUrl }));
        }
        if (hubUrl) {
          fetch(hubUrl + '/register', {
            method: 'POST',
            headers: { 'content-type': 'application/json', authorization: 'Bearer ' + (() => { try { return fs.readFileSync(HUB_TOKEN_FILE, 'utf8').trim(); } catch (_) { return ''; } })() },
            body: JSON.stringify({ name: 'A5-TELEFON', lan: (lanIP() || '') + ':' + PORT, kind: 'phone' }),
          }).catch(() => {});
        }
        return send(res, 200, { ok: true, hub: hubUrl, lan: lanIP() + ':' + PORT });
      } catch (e) { send(res, 400, { error: 'json hatalı' }); }
    });
    return;
  }

  send(res, 404, { error: 'bilinmeyen yol: ' + p });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log('panpi-phone dinliyor: 0.0.0.0:' + PORT);
  console.log('LAN: http://' + lanIP() + ':' + PORT);
  console.log('token: ' + token);
  // hub'a otomatik kayıt (kayıtlı hub varsa)
  try {
    const reg = JSON.parse(fs.readFileSync(REG_FILE, 'utf8'));
    if (reg.hub) {
      fetch(reg.hub + '/register', {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: 'Bearer ' + (() => { try { return fs.readFileSync(HUB_TOKEN_FILE, 'utf8').trim(); } catch (_) { return ''; } })() },
        body: JSON.stringify({ name: 'A5-TELEFON', lan: lanIP() + ':' + PORT, kind: 'phone' }),
      }).catch(() => {});
    }
  } catch (_) {}
});